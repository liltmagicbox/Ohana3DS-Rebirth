Maybe you need .NET Framework

the Program automatically dumps mesh,texture, meshAnim,2dAnim,cameraAnim at:
dump\filename

Place model smd file to:
skeleton\
to see skeletal animation. or you can click import button manually.(no auto-dump!)

config:
1 to do,  0 to don't
autodump.txt  : automatically dumps all data.
loadmodel.txt  : load model in viewport, easy to see what skeletal animation is.